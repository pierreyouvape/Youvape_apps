<?php
/**
 * Data Fetcher - Récupère les données complètes depuis WordPress/WooCommerce
 */

namespace YouSync;

defined('ABSPATH') || exit;

class Data_Fetcher {

    /**
     * Get full order data
     *
     * @param int $order_id
     * @return array|null
     */
    public static function get_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return null;
        }

        // Get customer
        $customer_id = $order->get_customer_id();

        // Get order items (line_item)
        $items = [];
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $items[] = [
                'item_id' => $item->get_id(),
                'product_id' => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'subtotal' => floatval($item->get_subtotal()),
                'total' => floatval($item->get_total()),
                'tax' => floatval($item->get_total_tax()),
                'sku' => $product ? $product->get_sku() : null,
                'tax_class' => $item->get_tax_class(),
                'line_subtotal_tax' => floatval(wc_get_order_item_meta($item->get_id(), '_line_subtotal_tax', true)) ?: 0,
                'line_tax_data' => wc_get_order_item_meta($item->get_id(), '_line_tax_data', true) ?: null,
                'product_attributes' => ($product && $product->is_type('variation')) ? $product->get_variation_attributes() : null,
                'advanced_discount' => wc_get_order_item_meta($item->get_id(), '_advanced_woo_discount_item_total_discount', true) ?: null,
                'wdr_discounts' => wc_get_order_item_meta($item->get_id(), '_wdr_discounts', true) ?: null,
                'item_cost' => floatval(wc_get_order_item_meta($item->get_id(), '_wc_cog_item_cost', true)) ?: null,
                'item_total_cost' => floatval(wc_get_order_item_meta($item->get_id(), '_wc_cog_item_total_cost', true)) ?: null,
                'reduced_stock' => (bool) wc_get_order_item_meta($item->get_id(), '_reduced_stock', true),
            ];
        }

        // Get shipping
        $shipping_items = [];
        $shipping_method = null;
        foreach ($order->get_items('shipping') as $item) {
            $shipping_items[] = [
                'method_id' => $item->get_method_id(),
                'method_title' => $item->get_method_title(),
                'total' => floatval($item->get_total())
            ];
            // Récupérer la première méthode de livraison
            if ($shipping_method === null) {
                $shipping_method = $item->get_method_title();
            }
        }

        // Get BMS shipping data (carrier and tracking)
        $shipping_carrier = $order->get_meta('bms_carrier');
        $tracking_number = $order->get_meta('bms_tracking_number');

        // Point relais choisi par le client (voir get_relay_point)
        $relay_point = self::get_relay_point($order);

        // Get coupons (codes for backward compat + detailed items)
        $coupons = [];
        foreach ($order->get_coupon_codes() as $code) {
            $coupons[] = $code;
        }

        $coupon_items = [];
        foreach ($order->get_items('coupon') as $item) {
            $coupon_items[] = [
                'item_id'         => $item->get_id(),
                'name'            => $item->get_name(),
                'discount_amount' => floatval($item->get_discount()),
                'discount_tax'    => floatval($item->get_discount_tax()),
            ];
        }

        // Get fee items
        $fee_items = [];
        foreach ($order->get_items('fee') as $item) {
            $fee_items[] = [
                'item_id'    => $item->get_id(),
                'name'       => $item->get_name(),
                'total'      => floatval($item->get_total()),
                'total_tax'  => floatval($item->get_total_tax()),
                'tax_class'  => $item->get_tax_class(),
                'tax_status' => $item->get_tax_status(),
            ];
        }

        // Get tax items
        $tax_items = [];
        foreach ($order->get_items('tax') as $item) {
            $tax_items[] = [
                'item_id'             => $item->get_id(),
                'rate_code'           => $item->get_rate_code(),
                'rate_id'             => $item->get_rate_id(),
                'label'               => $item->get_label(),
                'compound'            => $item->get_compound(),
                'tax_amount'          => floatval($item->get_tax_total()),
                'shipping_tax_amount' => floatval($item->get_shipping_tax_total()),
            ];
        }

        // Get attribution marketing data
        $attribution = [
            'source_type'        => $order->get_meta('_wc_order_attribution_source_type') ?: null,
            'referrer'           => $order->get_meta('_wc_order_attribution_referrer') ?: null,
            'utm_source'         => $order->get_meta('_wc_order_attribution_utm_source') ?: null,
            'utm_medium'         => $order->get_meta('_wc_order_attribution_utm_medium') ?: null,
            'utm_campaign'       => $order->get_meta('_wc_order_attribution_utm_campaign') ?: null,
            'utm_content'        => $order->get_meta('_wc_order_attribution_utm_content') ?: null,
            'utm_term'           => $order->get_meta('_wc_order_attribution_utm_term') ?: null,
            'device_type'        => $order->get_meta('_wc_order_attribution_device_type') ?: null,
            'user_agent'         => $order->get_meta('_wc_order_attribution_user_agent') ?: null,
            'session_entry'      => $order->get_meta('_wc_order_attribution_session_entry') ?: null,
            'session_start_time' => $order->get_meta('_wc_order_attribution_session_start_time') ?: null,
            'session_pages'      => intval($order->get_meta('_wc_order_attribution_session_pages')) ?: null,
            'session_count'      => intval($order->get_meta('_wc_order_attribution_session_count')) ?: null,
        ];

        // Get payment metadata (Mollie + generic)
        $payment_meta = [
            'transaction_id'              => $order->get_transaction_id() ?: null,
            'mollie_payment_id'           => $order->get_meta('_mollie_payment_id') ?: null,
            'mollie_order_id'             => $order->get_meta('_mollie_order_id') ?: null,
            'mollie_payment_mode'         => $order->get_meta('_mollie_payment_mode') ?: null,
            'mollie_customer_id'          => $order->get_meta('_mollie_customer_id') ?: null,
            'mollie_payment_instructions' => $order->get_meta('_mollie_payment_instructions') ?: null,
            'mollie_paid_and_processed'   => (bool) $order->get_meta('_mollie_paid_and_processed'),
        ];

        return [
            'wp_order_id' => $order->get_id(),
            'order_number' => $order->get_order_number(),
            'status' => $order->get_status(),
            'currency' => $order->get_currency(),
            'total' => floatval($order->get_total()),
            'subtotal' => floatval($order->get_subtotal()),
            'total_tax' => floatval($order->get_total_tax()),
            'shipping_total' => floatval($order->get_shipping_total()),
            'discount_total' => floatval($order->get_discount_total()),
            'payment_method' => $order->get_payment_method(),
            'payment_method_title' => $order->get_payment_method_title(),
            'customer_id' => $customer_id ?: null,
            'customer_email' => $order->get_billing_email(),
            'billing_first_name' => $order->get_billing_first_name(),
            'billing_last_name' => $order->get_billing_last_name(),
            'billing_company' => $order->get_billing_company(),
            'billing_address_1' => $order->get_billing_address_1(),
            'billing_address_2' => $order->get_billing_address_2(),
            'billing_city' => $order->get_billing_city(),
            'billing_postcode' => $order->get_billing_postcode(),
            'billing_country' => $order->get_billing_country(),
            'billing_phone' => $order->get_billing_phone(),
            'shipping_first_name' => $order->get_shipping_first_name(),
            'shipping_last_name' => $order->get_shipping_last_name(),
            'shipping_address_1' => $order->get_shipping_address_1(),
            'shipping_address_2' => $order->get_shipping_address_2(),
            'shipping_city' => $order->get_shipping_city(),
            'shipping_postcode' => $order->get_shipping_postcode(),
            'shipping_country' => $order->get_shipping_country(),
            'customer_note' => $order->get_customer_note(),
            'date_created' => $order->get_date_created() ? $order->get_date_created()->format('Y-m-d H:i:s') : null,
            'date_modified' => $order->get_date_modified() ? $order->get_date_modified()->format('Y-m-d H:i:s') : null,
            'date_completed' => $order->get_date_completed() ? $order->get_date_completed()->format('Y-m-d H:i:s') : null,
            'date_paid' => $order->get_date_paid() ? $order->get_date_paid()->format('Y-m-d H:i:s') : null,
            'items' => $items,
            'shipping' => $shipping_items,
            'shipping_method' => $shipping_method,
            'shipping_carrier' => $shipping_carrier ?: null,
            'tracking_number' => $tracking_number ?: null,
            'relay_point' => $relay_point,
            'coupons' => $coupons,
            'coupon_items' => $coupon_items,
            'fee_items' => $fee_items,
            'tax_items' => $tax_items,
            'attribution' => $attribution,
            'payment_meta' => $payment_meta
        ];
    }

    /**
     * Point relais choisi par le client, normalisé quel que soit le plugin d'origine.
     *
     * Trois plugins coexistent sur la boutique et ne stockent pas la même chose :
     *
     *  - Mondial Relay et Chronopost (plugins WMS) écrivent un tableau sérialisé sous
     *    une clé par réseau. Sa clé `shipping_method` distingue Chrono Relais de 2Shop
     *    (`chronopost_relais`, `chronopost_2shop`, `chronopost_2shop_europe`), ce qui
     *    déterminera lequel des deux contrats Chronopost utiliser. Elle est absente des
     *    enregistrements laissés par les anciennes versions du plugin (variante à
     *    7 clés) : on la transmet quand elle existe, sans en dépendre — le titre de la
     *    méthode de livraison reste la source fiable côté VPS.
     *
     *  - Colissimo (plugin officiel La Poste, préfixe `lpc`) éclate l'information sur
     *    quatre métas. `_lpc_meta_pickUpProductCode` contient le *type de point*
     *    (PCS, CMT, BPR, A2P…), pas le code produit de l'envoi : l'API le réclame à
     *    côté de l'identifiant du point.
     *
     * Sans identifiant de point, aucun de ces transporteurs n'accepte l'expédition.
     * C'est la donnée qui manquait pour générer les étiquettes en point relais.
     *
     * @param WC_Order $order
     * @return array|null
     */
    private static function get_relay_point($order) {
        // Mondial Relay et Chronopost : même plugin, même structure
        $wms_networks = [
            '_wms_mondial_relay_pickup_info' => 'mondial_relay',
            '_wms_chronopost_pickup_info'    => 'chronopost',
        ];

        foreach ($wms_networks as $meta_key => $network) {
            // maybe_unserialize : WooCommerce désérialise déjà la plupart des métas,
            // mais pas toutes selon le mode de stockage (HPOS ou postmeta).
            $info = maybe_unserialize($order->get_meta($meta_key));

            if (!is_array($info) || empty($info['pickup_id'])) {
                continue;
            }

            return [
                'network'  => $network,
                'id'       => (string) $info['pickup_id'],
                'name'     => $info['pickup_name'] ?? null,
                'address'  => $info['pickup_address'] ?? null,
                'postcode' => $info['pickup_zipcode'] ?? null,
                'city'     => $info['pickup_city'] ?? null,
                'country'  => $info['pickup_country'] ?? null,
                'type'     => null,
                'service'  => $info['shipping_method'] ?? null,
            ];
        }

        // Colissimo : quatre métas séparées, la fiche complète du point est en JSON
        $colissimo_id = $order->get_meta('_lpc_meta_pickUpLocationId');

        if (!empty($colissimo_id)) {
            $data = json_decode($order->get_meta('_lpc_meta_pickUpLocationData'), true);
            $data = is_array($data) ? $data : [];

            return [
                'network'  => 'colissimo',
                'id'       => (string) $colissimo_id,
                'name'     => $order->get_meta('_lpc_meta_pickUpLocationLabel') ?: ($data['nom'] ?? null),
                'address'  => $data['adresse1'] ?? null,
                'postcode' => $data['codePostal'] ?? null,
                'city'     => $data['localite'] ?? null,
                'country'  => $data['codePays'] ?? null,
                'type'     => $order->get_meta('_lpc_meta_pickUpProductCode') ?: ($data['typeDePoint'] ?? null),
                'service'  => null,
            ];
        }

        return null;
    }

    /**
     * Get full product data
     *
     * @param int $product_id
     * @return array|null
     */
    public static function get_product($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return null;
        }

        $data = [
            'wp_product_id' => $product->get_id(),
            'parent_id' => $product->get_parent_id(),
            'type' => $product->get_type(),
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'sku' => $product->get_sku(),
            'status' => $product->get_status(),
            'description' => $product->get_description(),
            'short_description' => $product->get_short_description(),
            'price' => floatval($product->get_price()),
            'regular_price' => floatval($product->get_regular_price()),
            'sale_price' => $product->get_sale_price() ? floatval($product->get_sale_price()) : null,
            'on_sale' => $product->is_on_sale(),
            'stock_quantity' => $product->get_stock_quantity(),
            'stock_status' => $product->get_stock_status(),
            'manage_stock' => $product->get_manage_stock(),
            'weight' => $product->get_weight(),
            'length' => $product->get_length(),
            'width' => $product->get_width(),
            'height' => $product->get_height(),
            'tax_status' => $product->get_tax_status(),
            'tax_class' => $product->get_tax_class(),
            'date_created' => $product->get_date_created() ? $product->get_date_created()->format('Y-m-d H:i:s') : null,
            'date_modified' => $product->get_date_modified() ? $product->get_date_modified()->format('Y-m-d H:i:s') : null,
            'image_url' => wp_get_attachment_url($product->get_image_id()) ?: (
                $product->get_parent_id() ? wp_get_attachment_url(get_post_thumbnail_id($product->get_parent_id())) ?: null : null
            ),
            'permalink' => get_permalink($product->get_id())
        ];

        // Get brand -- NE PAS REVENIR A $brands[0] (voir yousync/AVANT-DE-MODIFIER.md).
        // Un produit peut porter A LA FOIS le terme parent et son enfant
        // (ex. Eliquid France + Fruizee Max). $brands[0] renvoie le parent, donc
        // sub_brand part vide et ecrase la sous-marque en base a chaque edition.
        // On retient le terme qui a un parent : resultat independant de l'ordre.
        // La prod tourne encore en 1.4.0 avec l'ancien code ; le backend
        // (brandMapService) neutralise le bug en attendant.
        $brands = wp_get_post_terms($product->get_id(), 'pwb-brand', ['fields' => 'all']);
        if (!is_wp_error($brands) && !empty($brands)) {
            $child = null;
            foreach ($brands as $b) {
                if ($b->parent) { $child = $b; break; }
            }
            if ($child) {
                $data['sub_brand'] = $child->name;
                $parent_brand = get_term($child->parent, 'pwb-brand');
                $data['brand'] = ($parent_brand && !is_wp_error($parent_brand))
                    ? $parent_brand->name
                    : $child->name;
            } else {
                $data['brand'] = $brands[0]->name;
            }
        }

        // Get category
        $categories = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'all']);
        if (!is_wp_error($categories) && !empty($categories)) {
            $cat = $categories[0];
            $data['category'] = $cat->name;
            if ($cat->parent) {
                $parent_cat = get_term($cat->parent, 'product_cat');
                if ($parent_cat && !is_wp_error($parent_cat)) {
                    $data['category'] = $parent_cat->name;
                    $data['sub_category'] = $cat->name;
                }
            }
        }

        // Get attributes for variations
        if ($product->is_type('variation')) {
            $data['attributes'] = $product->get_variation_attributes();
        }

        // Get children for variable products (full data including image_url)
        if ($product->is_type('variable')) {
            $children_ids = $product->get_children();
            $data['variations'] = [];
            foreach ($children_ids as $child_id) {
                $child_data = self::get_product($child_id);
                if ($child_data) {
                    $data['variations'][] = $child_data;
                }
            }
        }

        return $data;
    }

    /**
     * Get full customer data
     *
     * @param int $customer_id
     * @return array|null
     */
    public static function get_customer($customer_id) {
        $customer = new \WC_Customer($customer_id);
        if (!$customer->get_id()) {
            return null;
        }

        $user = get_user_by('id', $customer_id);

        return [
            'wp_customer_id' => $customer->get_id(),
            'email' => $customer->get_email(),
            'first_name' => $customer->get_first_name(),
            'last_name' => $customer->get_last_name(),
            'display_name' => $customer->get_display_name(),
            'username' => $user ? $user->user_login : null,
            'billing_first_name' => $customer->get_billing_first_name(),
            'billing_last_name' => $customer->get_billing_last_name(),
            'billing_company' => $customer->get_billing_company(),
            'billing_address_1' => $customer->get_billing_address_1(),
            'billing_address_2' => $customer->get_billing_address_2(),
            'billing_city' => $customer->get_billing_city(),
            'billing_postcode' => $customer->get_billing_postcode(),
            'billing_country' => $customer->get_billing_country(),
            'billing_phone' => $customer->get_billing_phone(),
            'billing_email' => $customer->get_billing_email(),
            'shipping_first_name' => $customer->get_shipping_first_name(),
            'shipping_last_name' => $customer->get_shipping_last_name(),
            'shipping_company' => $customer->get_shipping_company(),
            'shipping_address_1' => $customer->get_shipping_address_1(),
            'shipping_address_2' => $customer->get_shipping_address_2(),
            'shipping_city' => $customer->get_shipping_city(),
            'shipping_postcode' => $customer->get_shipping_postcode(),
            'shipping_country' => $customer->get_shipping_country(),
            'date_created' => $customer->get_date_created() ? $customer->get_date_created()->format('Y-m-d H:i:s') : null,
            'date_modified' => $customer->get_date_modified() ? $customer->get_date_modified()->format('Y-m-d H:i:s') : null,
            'orders_count' => $customer->get_order_count(),
            'total_spent' => floatval($customer->get_total_spent())
        ];
    }

    /**
     * Get full refund data
     *
     * @param int $refund_id
     * @return array|null
     */
    public static function get_refund($refund_id) {
        $refund = wc_get_order($refund_id);
        if (!$refund || $refund->get_type() !== 'shop_order_refund') {
            return null;
        }

        return [
            'wp_refund_id' => $refund->get_id(),
            'wp_order_id' => $refund->get_parent_id(),
            'refund_amount' => floatval($refund->get_amount()),
            'refund_reason' => $refund->get_reason(),
            'refund_date' => $refund->get_date_created() ? $refund->get_date_created()->format('Y-m-d H:i:s') : null,
            'refunded_by' => $refund->get_refunded_by()
        ];
    }
}
